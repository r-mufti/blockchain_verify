// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

/// @title CertificateRegistry
/// @notice Issues, verifies, and revokes tamper-proof academic/professional certificates on-chain
/// @dev Each certificate is identified by a keccak256 hash of its metadata

contract CertificateRegistry {

    // ─── Structs ────────────────────────────────────────────────────────────

    struct Certificate {
        bytes32  certId;          // Unique on-chain ID (keccak256 hash)
        address  issuer;          // Wallet address of the issuing institution
        address  recipient;       // Wallet address of the certificate holder
        string   recipientName;   // Full name of the recipient
        string   courseName;      // Course / degree / certification title
        string   ipfsHash;        // IPFS CID of the full PDF certificate
        uint256  issuedAt;        // Block timestamp at issuance
        uint256  expiresAt;       // 0 = never expires
        bool     revoked;         // Revocation flag
        string   revocationNote;  // Reason for revocation (if any)
    }

    // ─── State ──────────────────────────────────────────────────────────────

    address public owner;

    /// certId → Certificate
    mapping(bytes32 => Certificate) private _certificates;

    /// issuer address → authorized flag
    mapping(address => bool) public authorizedIssuers;

    /// recipient address → list of their certIds
    mapping(address => bytes32[]) private _recipientCerts;

    /// issuer address → list of certIds they issued
    mapping(address => bytes32[]) private _issuerCerts;

    // ─── Events ─────────────────────────────────────────────────────────────

    event IssuerAuthorized(address indexed issuer);
    event IssuerRevoked(address indexed issuer);
    event CertificateIssued(
        bytes32 indexed certId,
        address indexed issuer,
        address indexed recipient,
        string courseName,
        uint256 issuedAt
    );
    event CertificateRevoked(bytes32 indexed certId, string reason);

    // ─── Modifiers ──────────────────────────────────────────────────────────

    modifier onlyOwner() {
        require(msg.sender == owner, "CertReg: not owner");
        _;
    }

    modifier onlyAuthorized() {
        require(authorizedIssuers[msg.sender], "CertReg: not an authorized issuer");
        _;
    }

    // ─── Constructor ────────────────────────────────────────────────────────

    constructor() {
        owner = msg.sender;
        authorizedIssuers[msg.sender] = true; // owner is automatically authorized
    }

    // ─── Admin ──────────────────────────────────────────────────────────────

    /// @notice Grant issuing rights to an institution wallet
    function authorizeIssuer(address issuer) external onlyOwner {
        require(issuer != address(0), "CertReg: zero address");
        authorizedIssuers[issuer] = true;
        emit IssuerAuthorized(issuer);
    }

    /// @notice Remove issuing rights from an institution
    function revokeIssuerAccess(address issuer) external onlyOwner {
        authorizedIssuers[issuer] = false;
        emit IssuerRevoked(issuer);
    }

    // ─── Core ───────────────────────────────────────────────────────────────

    /// @notice Issue a new certificate
    /// @param recipient    Wallet address of the student/professional
    /// @param recipientName Full name printed on the certificate
    /// @param courseName   Name of the course or degree
    /// @param ipfsHash     IPFS CID pointing to the certificate PDF
    /// @param expiresAt    Unix timestamp for expiry; pass 0 for lifetime validity
    /// @return certId      The unique blockchain ID of this certificate
    function issueCertificate(
        address  recipient,
        string calldata recipientName,
        string calldata courseName,
        string calldata ipfsHash,
        uint256 expiresAt
    ) external onlyAuthorized returns (bytes32 certId) {
        require(recipient != address(0), "CertReg: zero recipient");
        require(bytes(recipientName).length > 0, "CertReg: empty name");
        require(bytes(courseName).length > 0, "CertReg: empty course");
        require(expiresAt == 0 || expiresAt > block.timestamp, "CertReg: expiry in the past");

        // Derive a deterministic unique ID from key fields
        certId = keccak256(
            abi.encodePacked(
                msg.sender,
                recipient,
                courseName,
                block.timestamp,
                block.number
            )
        );

        require(_certificates[certId].issuedAt == 0, "CertReg: duplicate cert");

        _certificates[certId] = Certificate({
            certId:          certId,
            issuer:          msg.sender,
            recipient:       recipient,
            recipientName:   recipientName,
            courseName:      courseName,
            ipfsHash:        ipfsHash,
            issuedAt:        block.timestamp,
            expiresAt:       expiresAt,
            revoked:         false,
            revocationNote:  ""
        });

        _recipientCerts[recipient].push(certId);
        _issuerCerts[msg.sender].push(certId);

        emit CertificateIssued(certId, msg.sender, recipient, courseName, block.timestamp);
    }

    /// @notice Revoke a previously issued certificate
    /// @param certId Unique certificate ID
    /// @param reason Human-readable reason for revocation
    function revokeCertificate(bytes32 certId, string calldata reason) external {
        Certificate storage cert = _certificates[certId];
        require(cert.issuedAt != 0, "CertReg: cert not found");
        require(cert.issuer == msg.sender || msg.sender == owner, "CertReg: not authorized to revoke");
        require(!cert.revoked, "CertReg: already revoked");

        cert.revoked = true;
        cert.revocationNote = reason;

        emit CertificateRevoked(certId, reason);
    }

    // ─── Verification ────────────────────────────────────────────────────────

    /// @notice Verify a certificate and return its full status
    /// @return valid      True if certificate exists, is not revoked, and not expired
    /// @return cert       The full Certificate struct
    /// @return status     Human-readable status string
    function verifyCertificate(bytes32 certId)
        external
        view
        returns (
            bool valid,
            Certificate memory cert,
            string memory status
        )
    {
        cert = _certificates[certId];

        if (cert.issuedAt == 0) {
            return (false, cert, "NOT_FOUND");
        }
        if (cert.revoked) {
            return (false, cert, "REVOKED");
        }
        if (cert.expiresAt != 0 && block.timestamp > cert.expiresAt) {
            return (false, cert, "EXPIRED");
        }

        return (true, cert, "VALID");
    }

    /// @notice Check if a certificate ID exists on-chain
    function exists(bytes32 certId) external view returns (bool) {
        return _certificates[certId].issuedAt != 0;
    }

    // ─── Getters ─────────────────────────────────────────────────────────────

    /// @notice Get all certificate IDs issued to a recipient
    function getCertsByRecipient(address recipient) external view returns (bytes32[] memory) {
        return _recipientCerts[recipient];
    }

    /// @notice Get all certificate IDs issued by an issuer
    function getCertsByIssuer(address issuer) external view returns (bytes32[] memory) {
        return _issuerCerts[issuer];
    }

    /// @notice Compute what a certId would be (for off-chain preview)
    function computeCertId(
        address issuer,
        address recipient,
        string calldata courseName,
        uint256 timestamp,
        uint256 blockNum
    ) external pure returns (bytes32) {
        return keccak256(abi.encodePacked(issuer, recipient, courseName, timestamp, blockNum));
    }

    // ─── Transfer Ownership ──────────────────────────────────────────────────

    function transferOwnership(address newOwner) external onlyOwner {
        require(newOwner != address(0), "CertReg: zero address");
        owner = newOwner;
    }
}
